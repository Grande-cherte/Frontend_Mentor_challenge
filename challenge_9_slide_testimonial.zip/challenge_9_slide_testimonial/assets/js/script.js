$('.slider').slick({
    lazyLoad: "progressive",
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    prevArrow: $('.prev'),
    nextArrow: $('.next'),
    fade: true,
    autoplay: true
});
